package ch.walica.temp51224_3tp_2_btn;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnShowHideText, btnShowHideText2, btnShowToast;
    private TextView tvLeft, tvRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShowHideText = findViewById(R.id.btnShowHideText);
        btnShowHideText2 = findViewById(R.id.btnShowHideText2);
        btnShowToast = findViewById(R.id.btnShowToast);
        tvLeft = findViewById(R.id.tvLeft);
        tvRight = findViewById(R.id.tvRight);

        btnShowHideText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvLeft.getText() == "") {
                    tvLeft.setText("lewa strona");
                    btnShowHideText.setText("Ukryj");
                } else {
                    tvLeft.setText("");
                    btnShowHideText.setText("Pokaż");
                }

            }
        });

        btnShowHideText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvRight.getVisibility() == View.INVISIBLE) {
                    tvRight.setVisibility(View.VISIBLE);
                    btnShowHideText2.setText("Ukryj");
                } else {
                    tvRight.setVisibility(View.INVISIBLE);
                    btnShowHideText2.setText("Pokaż");
                }
            }
        });

        btnShowToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Komunikat w Toast", Toast.LENGTH_SHORT).show();
            }
        });

    }
}