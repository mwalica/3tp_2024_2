package ch.walica.temp200325_3tp_2_saveinstantstate;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton floatingActionButton, floatingActionButton2;
    private TextView tvCount;
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton2 = findViewById(R.id.floatingActionButton2);
        tvCount = findViewById(R.id.tvCount);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt("counter_key");
        }


        tvCount.setText(String.valueOf(counter));

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter--;
                tvCount.setText(String.valueOf(counter));
            }
        });

        floatingActionButton2.setOnClickListener(view -> {
            counter++;
            tvCount.setText(String.valueOf(counter));
        });

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter_key",counter);
    }
}