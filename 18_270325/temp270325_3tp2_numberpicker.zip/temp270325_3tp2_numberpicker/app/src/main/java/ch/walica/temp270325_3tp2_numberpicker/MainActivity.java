package ch.walica.temp270325_3tp2_numberpicker;

import android.os.Bundle;
import android.util.Log;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "my_log";
    private NumberPicker numberPicker1, numberPicker2;
    private TextView tvResult1, tvResult2;
    private int selectedValue = 15;

    private String[] names = {"Jan", "Adam", "Kasia", "Zosia"};
    private int selectedNameIndex = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        numberPicker1 = findViewById(R.id.numberPicker1);
        numberPicker2 = findViewById(R.id.numberPicker2);
        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);

        if(savedInstanceState != null) {
            selectedValue = savedInstanceState.getInt("number_key");
            selectedNameIndex = savedInstanceState.getInt("name_key");
        }

        numberPicker1.setMaxValue(20);
        numberPicker1.setMinValue(10);
        numberPicker1.setValue(selectedValue);

        numberPicker2.setMaxValue(names.length - 1);
        numberPicker2.setDisplayedValues(names);
        numberPicker2.setValue(selectedNameIndex);

        tvResult1.setText(String.valueOf(selectedValue));
        tvResult2.setText(names[selectedNameIndex]);

        numberPicker2.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                selectedNameIndex = newVal;
                tvResult2.setText(names[selectedNameIndex]);
            }
        });

        numberPicker1.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                Log.d(TAG, "oldVal: " + oldVal);
                Log.d(TAG, "newVal: " + newVal);
                selectedValue = newVal;
                tvResult1.setText(String.valueOf(selectedValue));
            }
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("number_key", selectedValue);
        outState.putInt("name_key", selectedNameIndex);
    }
}