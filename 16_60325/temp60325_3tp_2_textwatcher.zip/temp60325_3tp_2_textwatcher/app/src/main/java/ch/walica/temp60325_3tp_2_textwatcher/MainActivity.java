package ch.walica.temp60325_3tp_2_textwatcher;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.LongDef;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private TextView tvResult;
    private String enteredText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        etEnteredText = findViewById(R.id.etEnteredText);
        tvResult = findViewById(R.id.tvResult);

        etEnteredText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence text, int start, int before, int count) {
                Log.d("my_log", "text = " + text);
                Log.d("my_log", "start = " + start);
                enteredText = text.toString().toUpperCase();
                tvResult.setText(enteredText);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }
}