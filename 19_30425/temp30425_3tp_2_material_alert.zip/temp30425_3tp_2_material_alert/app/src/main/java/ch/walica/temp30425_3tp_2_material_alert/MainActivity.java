package ch.walica.temp30425_3tp_2_material_alert;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import ch.walica.temp30425_3tp_2_material_alert.model.Person;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker;
    private Button btnSelect;
    private int selectedIndex = 0;
    private Person[] people = {
            new Person("Jan"),
            new Person("Adam"),
            new Person("Karolina"),
            new Person("Gustaw"),
    };
    private String[] names = new String[people.length];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        numberPicker = findViewById(R.id.numberPicker);
        btnSelect = findViewById(R.id.btnSelect);

        for(int i = 0; i < people.length; i++) {
            names[i] = people[i].getName();
        }

        numberPicker.setDisplayedValues(names);
        numberPicker.setMaxValue(names.length - 1);
        numberPicker.setValue(selectedIndex);

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                selectedIndex = newVal;
            }
        });

        btnSelect.setOnClickListener(view -> {
            new MaterialAlertDialogBuilder(MainActivity.this)
                    .setTitle("Wybrana osoba")
                    .setMessage(people[selectedIndex].getName() + " " + people[selectedIndex].getAge() + " lat.")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.d("my_log", "positive: " + which);
                            Toast.makeText(MainActivity.this, "Wybrałeś osobę", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Nie", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.d("my_log", "negative: " + which);
                            finish();
                        }
                    })
                    .setNeutralButton("Anuluj", null)
                    .setCancelable(false)
                    .show();
        });

    }
}