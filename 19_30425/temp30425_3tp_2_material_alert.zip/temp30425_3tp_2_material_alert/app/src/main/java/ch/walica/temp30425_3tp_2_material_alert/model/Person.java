package ch.walica.temp30425_3tp_2_material_alert.model;

import java.util.Random;

public class Person {
    private String name;
    private int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(80) + 18;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
