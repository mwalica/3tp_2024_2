package ch.walica.temp281124_3tp_2_1;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private LinearLayout ll1, ll2, ll3, ll4;
    private TextView tvText1, tvText2, tvText3, tvText4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ll1 = findViewById(R.id.ll1);
        ll2 = findViewById(R.id.ll2);
        ll3 = findViewById(R.id.ll3);
        ll4 = findViewById(R.id.ll4);

        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);
        tvText3 = findViewById(R.id.tvText3);
        tvText4 = findViewById(R.id.tvText4);

        ll1.setBackgroundColor(Color.rgb(randomNum(), randomNum(), randomNum()));
        ll2.setBackgroundColor(Color.rgb(randomNum(), randomNum(), randomNum()));
        ll3.setBackgroundColor(Color.rgb(randomNum(), randomNum(), randomNum()));
        ll4.setBackgroundColor(Color.rgb(randomNum(), randomNum(), randomNum()));

        int num1 = randomNum1();
        int num2 = randomNum1();
        int num3 = randomNum1();
        int num4 = randomNum1();

        tvText1.setText(String.valueOf(num1));
        tvText1.setTextSize(num1);

    }

    private int randomNum() {
        return new Random().nextInt(256);
    }

    private int randomNum1() {
        return new Random().nextInt(81) + 16;
    }


}