package ch.walica.temp121224_3tp_2_toast_zad;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnRandom;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        btnRandom = findViewById(R.id.btnRandom);

        btnRandom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int randomNum = random.nextInt(101);
                tvResult.setText(randomNum + "%");
                String msg = "";
                if(randomNum > 95) {
                    msg = "celujący";
                } else if(randomNum > 85) {
                    msg = "bardzo dobry";
                } else if(randomNum > 75) {
                    msg = "dobry";
                } else if (randomNum > 65) {
                    msg = "dostateczny";
                } else if(randomNum > 50) {
                    msg = "dopuszczający";
                } else {
                    msg = "niedostateczny";
                }

                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });

    }
}